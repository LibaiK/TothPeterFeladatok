
apiUrl="https://swapi.dev/api/people";

getData(apiUrl).then(res=>{
  console.log(res);
  writePerson(res);
})
.catch(err=>{
  console.log(err);
})



function getData(url){
  return new Promise(function(resolve, reject){
      const xhr = new XMLHttpRequest();
      xhr.open("GET", url)
      xhr.send()

      xhr.onload = function(){
          resolve(JSON.parse(xhr.response).results);
      }
      xhr.onerror = function(){
          reject({
              status: xhr.status,
              statusText: xhr.statusText
          })
      }
  })
}
function writePerson(peoples){
  let table = document.getElementById("starwarsTable");
  console.log(peoples);
  for(let people of peoples){
    let td = document.createElement("td");
    let td2 = document.createElement("td");
    let td3 = document.createElement("td");
    let td4 = document.createElement("td");
    let tr = document.createElement("tr");
    let text = document.createTextNode(people.name);
    let text2 = document.createTextNode(people.height);
    let text3 = document.createTextNode(people.mass);
    let text4  = document.createTextNode(people.birth_year);

    td.appendChild(text);
    td2.appendChild(text2);
    td3.appendChild(text3);
    td4.appendChild(text4);
    tr.appendChild(td);
    tr.appendChild(td2);
    tr.appendChild(td3);
    tr.appendChild(td4);
    table.appendChild(tr);

  }
}

