
const postUrl = "https://jsonplaceholder.typicode.com/posts"
const userUrl = "https://jsonplaceholder.typicode.com/users"

var userName;



for(let i = 1; i<=10; i++){
    getData(postUrl + "/" + getRandomNumber(1, 100), true)
    .then(function(post){
        console.log(post)

        getData(userUrl + "/" + post.userId, true)
        .then(function(user){
            console.log(user)


            getData(postUrl + "/" + post.id + "/comments", true)
            .then(function(comment){
                console.log(comment)

                writePost(post, user, comment)
            })
        })

    })
    .catch(function(errorStatus){
        console.log(errorStatus)
    })
}


function getData(url, assync){

    return new Promise(function(resolve, reject){
        const xhr = new XMLHttpRequest();
        xhr.onload = function(){

            if(this.status>=200 && this.status <=299){
                resolve(JSON.parse(this.responseText))
            }
            else if(this.status>=400 && this.status <=499){
                reject({
                    status: this.status,
                    statusText: this.statusText
                })
            }
            else if(this.status>=500 && this.status <=599){
                reject({
                    status: this.status,
                    statusText: this.statusText
                })
            }


        }
        xhr.onerror = function(){
            reject({
                status: this.status,
                statusText: this.statusText
            })
        }
        xhr.open("GET", url, assync)
        xhr.send()
    })



}

function writeResToConsol(xhrResponse){
    console.log(xhrResponse.responseText)
}

function getRandomNumber(min, max){
    return Math.floor(Math.random() * (max - min +1) + min)
}

function writePost(post, user){

    let position = document.getElementById("posts")

    let userName = document.createTextNode(user.name)
    let h2 = document.createElement("h2")
    let div = document.createElement("div")

    let postTitle = document.createTextNode(post.title)
    let ptag = document.createElement("p")

    h2.setAttribute('class', 'postUser')
    div.setAttribute('class', 'post')
    h2.appendChild(userName)
    div.appendChild(h2)

    ptag.appendChild(postTitle)
    div.appendChild(ptag)

    position.appendChild(div)
}
